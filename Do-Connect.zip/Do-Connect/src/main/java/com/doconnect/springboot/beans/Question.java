package com.doconnect.springboot.beans;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.*;

@Entity(name="question")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Question {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int question_id;
	private String question;
	
	@ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "admin_id")
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    private Admin admin;
	
	@OneToMany(mappedBy = "question1", cascade = CascadeType.ALL)
	
    private Set<Answer> answersss = new HashSet<>();
	
	
    
	
	public int getQuestion_id() {
		return question_id;
	}
	public String getQuestion() {
		return question;
	}
	public void setQuestion_id(int question_id) {
		this.question_id = question_id;
	}
	public void setQuestion(String question) {
		this.question = question;
	}
	
	
	
	



	
		
	}