package com.doconnect.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DoConnectApplicationTests {

	@Test
	void contextLoads() {
	}

}
